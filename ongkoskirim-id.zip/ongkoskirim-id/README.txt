=== Plugin Ongkos Kirim JNE Tiki Sicepat Wahana J&T POS for Woocommerce ===
Contributors: oggix
Donate link: http://plugin.ongkoskirim.id/
Tags: shipping, jne , wahana, jnt, sicepat, ongkos kirim, pos, ecommerce, commerce, store, shop, sell, woocommerce, online store, cart, checkout, shopping, indonesia, tiki, jogjacamp
Requires at least: 3.0.1
Tested up to: 4.9
Stable tag: 4.3
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

OngkosKirim.id merupakan plugin ongkos kirim woocommerce dengan fitur terkomplit dan ekspedisi terlengkap, meliputi JNE, TIKI, POS, J&T, Sicepat, Wahana

== Description ==

OngkosKirim.id merupakan plugin tambahan untuk woocommerce yang berfungsi untuk menghitung ongkos kirim dari berbagai ekspedisi di Indonesia, mulai dari JNE, Tiki, Pos, J&T, Sicepat dan Wahana.
Plugin ini sangat mudah digunakan, hanya cukup sekali klik dan anda siap berjualan ke seluruh pelosok negri.

== Features Free Version ==

* Ongkos Kirim Real-Time Seluruh Indonesia
* Ongkir kirim JNE, TIKI, POS, J&T, Sicepat, Wahana
* Data kota dari basis kota pengiriman Anda ke Seluruh Indonesia
* Checkout Provinsi, Kota, Kecamatan saling terkait
* Fitur Kalkulasi Ongkir di Halaman Cart
* Terintegrasi Dengan Woo Commerce
* Fitur Ongkos Kirim Tambahan
* Angka Unik Transaksi
* Ongkos Kirim Hingga Kecamatan
* Multiple Currency
* Mudah di Install & Digunakan
* Multi Bahasa
* Gratis update dan Dukungan Teknis Profesional

== Features PRO Version ==

* Semua fitur di Free Version
* Ongkos kirim JNE YES, TIKI ONS, Sicepat BEST

[Upgrade ke PRO version](http://plugin.ongkoskirim.id/ "Upgrade ke PRO version")


== Installation ==

1. Download file plugin di sini http://plugin.ongkoskirim.id/
2. Dari halaman admin wordpress, buka menu Plugins » Add New » Upload Plugin
3. Upload file plugin yang sudah Anda download diatas, kemudian klik tombol Install Now

== Frequently Asked Questions ==

= Apa itu plugin OngkosKirim.id? =

Plugin OngkosKirim.id merupakan plugin wordpress dan woocommerce untuk menghitung ongkos kirim ekspedisi di Indonesia, seperti JNE, TIKI, POS, Sicepat dan lain-lain.

= Apakah saya bisa gunakan versi gratis dulu dan suatu saat upgrade? =

Ya, kamu bisa kapan saja upgrade paket.

= Apakah plugin ini kompatibel dengan website ku? =

Ya, plugin ini selalu diupdate dengan wordpress dan woocommerce terbaru. Jika mengalami kendala, team kami dengan senang hati akan memandu.


= Bagaimana jika harga ongkirnya di ekspedisi berubah? =

Data ongkos kirim kami update secara realtime, sehingga semua perubahan harga di ekspedisi akan ter-update juga website mu.




== Changelog ==

= 1.0.1 =
* Shipping weight in gram debug fix
* Fix php code warning & Notifications

= 1.0.0 =
* Initial release