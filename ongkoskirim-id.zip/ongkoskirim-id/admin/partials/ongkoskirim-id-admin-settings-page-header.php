<div class="ongkoskirim-id-head">
    <table class="ongkoskirim-id-status widefat" cellspacing="0">
        <thead>
        <tr><td>
                <a href="<?php echo $this->homepage_url; ?>"><img src="http://ongkoskirim.id/images/logo-text.jpg"></a></td></tr>
        </thead>
        <tbody>
        <tr>
            <th>

            </th>
        </tr>
        <tr>
            <td><?php echo __('Butuh bantuan?',"ongkoskirim-id"); ?><br>
                <?php echo __('Baca',"ongkoskirim-id"); ?> <a href="<?php echo $this->docs_url; ?>"><?php echo __('dokumentasi',"ongkoskirim-id"); ?></a> <?php echo __('atau kontak kami',"ongkoskirim-id"); ?> <a href="<?php echo $this->contact_url; ?>"><?php echo __('di sini',"ongkoskirim-id"); ?></a>.
            </td>
        </tr>
        </tbody>
    </table>
</div>